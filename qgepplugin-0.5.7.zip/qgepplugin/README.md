
qgepplugin
==========

This plugin is part of the QGEP Wastewater project for QGIS.

[![Build Status](https://travis-ci.org/QGEP/qgepplugin.svg?branch=master)](https://travis-ci.org/QGEP/qgepplugin)
