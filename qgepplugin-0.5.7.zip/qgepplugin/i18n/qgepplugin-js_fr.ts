<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>reach</name>
    <message>
        <source>Reach</source>
        <comment>Reach</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Material:</source>
        <comment>Material:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Width:</source>
        <comment>Width:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Length:</source>
        <comment>Length:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Gradient:</source>
        <comment>Gradient:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entry level:</source>
        <comment>Entry level:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Exit level:</source>
        <comment>Exit level:</comment>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>specialStructure</name>
    <message>
        <source>Manhole</source>
        <comment>Manhole</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cover level:</source>
        <comment>Cover level:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Bottom level:</source>
        <comment>Bottom level:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Entry level:</source>
        <comment>Entry level:</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Exit level:</source>
        <comment>Exit level:</comment>
        <translation type="unfinished"/>
    </message>
</context>
</TS>